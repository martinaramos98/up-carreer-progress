import { PeriodCourses } from "../../src/db/libsql/schemas/courses.ts";

export const periodsTestFixture: PeriodCourses[] = [{
  id: "0",
  description: "CUATRIMESTRAL",
}, {
  id: "1",
  description: "ANUAL",
}];

